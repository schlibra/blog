---
title: 深入浅出valine（二）配置SDK
abbrlink: 34079
date: 2023-01-14 18:30:12
tags:
customNextPre:
  prev:
    title: 深入浅出valine（一）准备
    path: https://xcgzs.cn/article/46933/
  next:
    title: 深入浅出valine（三）编写代码
    path: https://xcgzs.cn/article/41560/
---
